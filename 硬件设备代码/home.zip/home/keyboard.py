import time
import wiringpi

# 键盘相关引脚定义
row1 = 16
row2 = 15
row3 = 13
row4 = 10
col1 = 9
col2 = 6
col3 = 4
col4 = 3

def key_scan():
    wiringpi.digitalWrite(row1, 0)
    wiringpi.digitalWrite(row2, 1)
    wiringpi.digitalWrite(row3, 1)
    wiringpi.digitalWrite(row4, 1)
    if(not wiringpi.digitalRead(col1)):
        time.sleep(0.02)
        while(not wiringpi.digitalRead(col1)):
            time.sleep(0.02)
            return "1"
    if (not wiringpi.digitalRead(col2)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col2)):
            time.sleep(0.02)
            return "2"
    if (not wiringpi.digitalRead(col3)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col3)):
            time.sleep(0.02)
            return "3"
    if (not wiringpi.digitalRead(col4)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col4)):
            time.sleep(0.02)
            return "A"
    wiringpi.digitalWrite(row1, 1)
    wiringpi.digitalWrite(row2, 0)
    wiringpi.digitalWrite(row3, 1)
    wiringpi.digitalWrite(row4, 1)
    if(not wiringpi.digitalRead(col1)):
        time.sleep(0.02)
        while(not wiringpi.digitalRead(col1)):
            time.sleep(0.02)
            return "4"
    if (not wiringpi.digitalRead(col2)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col2)):
            time.sleep(0.02)
            return "5"
    if (not wiringpi.digitalRead(col3)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col3)):
            time.sleep(0.02)
            return "6"
    if (not wiringpi.digitalRead(col4)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col4)):
            time.sleep(0.02)
            return "B"
    wiringpi.digitalWrite(row1, 1)
    wiringpi.digitalWrite(row2, 1)
    wiringpi.digitalWrite(row3, 0)
    wiringpi.digitalWrite(row4, 1)
    if(not wiringpi.digitalRead(col1)):
        time.sleep(0.02)
        while(not wiringpi.digitalRead(col1)):
            time.sleep(0.02)
            return "7"
    if (not wiringpi.digitalRead(col2)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col2)):
            time.sleep(0.02)
            return "8"
    if (not wiringpi.digitalRead(col3)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col3)):
            time.sleep(0.02)
            return "9"
    if (not wiringpi.digitalRead(col4)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col4)):
            time.sleep(0.02)
            return "C"
    wiringpi.digitalWrite(row1, 1)
    wiringpi.digitalWrite(row2, 1)
    wiringpi.digitalWrite(row3, 1)
    wiringpi.digitalWrite(row4, 0)
    if(not wiringpi.digitalRead(col1)):
        time.sleep(0.02)
        while(not wiringpi.digitalRead(col1)):
            time.sleep(0.02)
            return "*"
    if (not wiringpi.digitalRead(col2)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col2)):
            time.sleep(0.02)
            return "0"
    if (not wiringpi.digitalRead(col3)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col3)):
            time.sleep(0.02)
            return "#"
    if (not wiringpi.digitalRead(col4)):
        time.sleep(0.02)
        while (not wiringpi.digitalRead(col4)):
            time.sleep(0.02)
            return "D"
    return "-1"