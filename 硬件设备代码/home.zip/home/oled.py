from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306
from PIL import ImageFont
import time
serial = i2c(port=3, address=0x3C)
device = ssd1306(serial)

# 用于加载字体，'simkai.ttf'为中文楷体，该文件可以直接从windows的C盘中搜索，然后复制过来放在与该程序同一文件夹下即可
# 后面的数字'15'为字体的大小
font = ImageFont.truetype('simkai.ttf', 15)

def write_oled(str0,str1,str2,str3):
    with canvas(device) as draw:
        draw.rectangle(device.bounding_box, outline="white", fill="black")  # 让屏幕周围显示一个框
        draw.text((5, 2), str0, font=font, fill="white")
        draw.text((5, 17), str1, font=font, fill="white")
        draw.text((5, 32), str2, font=font, fill="white")
        draw.text((5, 47), str3, font=font, fill="white")