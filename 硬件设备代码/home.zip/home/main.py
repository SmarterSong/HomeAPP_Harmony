import random
import time
import wiringpi
import demjson
import subprocess
import re
import oled
import keyboard
from datetime import timedelta, datetime
from timeloop import Timeloop
from paho.mqtt import client as mqtt_client
from wiringpi import GPIO

# 定时器
t1 = Timeloop()    # oled显示
t2 = Timeloop()    # 键盘扫描

# 初始化GPIO
wiringpi.wiringPiSetup()

# 引脚定义
smoke_pin = 0
fire_pin = 1
gate_pin = 5
garage_pin = 7
curtain_pin = 8
light_pin = 11
kongtiao_pin = 12
duoji_pin = 2



# 电机驱动
IN3 = 27
IN4 = 26
wiringpi.pinMode(IN3, GPIO.OUTPUT)
wiringpi.pinMode(IN4, GPIO.OUTPUT)
wiringpi.digitalWrite(IN3, 0)

# 键盘相关引脚定义
row1 = 16
row2 = 15
row3 = 13
row4 = 10
col1 = 9
col2 = 6
col3 = 4
col4 = 3
wiringpi.pinMode(row1, GPIO.OUTPUT)
wiringpi.pinMode(row2, GPIO.OUTPUT)
wiringpi.pinMode(row3, GPIO.OUTPUT)
wiringpi.pinMode(row4, GPIO.OUTPUT)
wiringpi.pinMode(col1, GPIO.INPUT)
wiringpi.pinMode(col2, GPIO.INPUT)
wiringpi.pinMode(col3, GPIO.INPUT)
wiringpi.pinMode(col4, GPIO.INPUT)
wiringpi.pullUpDnControl(col1, GPIO.PUD_UP)
wiringpi.pullUpDnControl(col2, GPIO.PUD_UP)
wiringpi.pullUpDnControl(col3, GPIO.PUD_UP)
wiringpi.pullUpDnControl(col4, GPIO.PUD_UP)


# 获取室温的命令
temp_command = "sensors"
# 播放音频命令
wav_command = "aplay "


# 舵机设置
init_value = 0      #占空比初始值
pwm_range = 200    #pwm范围

# 创建软件 PWM
wiringpi.pinMode(duoji_pin,1)
wiringpi.softPwmCreate(duoji_pin, init_value, pwm_range)


# 服务器信息
broker = '39.106.60.146'
port = 1883
# 设备唯一ID
client_id = f'python-mqtt-{random.randint(0, 1000)}'
# 主题
publish_topic = "home_01"
subscribe_topic = "phone_01"
# 家庭状态信息
temp = "0.0"
humidity = "50"
illumination = "0.0"
smoke = 0       # 0为正常状态，1为报警状态
fire = 0        # 0为正常状态，1为报警状态
gate = 0        # 0为关闭状态，1为打开状态
garage = 0      # 0为关闭状态，1为打开状态
curtain = 0     # 0为关闭状态，1为打开状态
light = 0       # 0为关闭状态，1为打开状态
kongtiao = 0    # 0为关闭状态，1为打开状态
send_dict = {"temp":         temp,
             "humidity":     humidity,
             "illumination": illumination,
             "smoke":        smoke,
             "fire":         fire,
             "gate":         gate,
             "garage":       garage,
             "curtain":      curtain,
             "light":        curtain,
             "kongtiao":     kongtiao
 }

wav_list = [
    {"smoke":          "./wav/smoke_0.wav",
     "fire":           "./wav/fire_0.wav",
     "gate":           "./wav/gate_0.wav",
     "garage":         "./wav/garage_0.wav",
     "curtain":        "./wav/curtain_0.wav",
     "light":          "./wav/light_0.wav",
     "kongtiao":       "./wav/kongtiao_0.wav"},
    {"smoke":          "./wav/smoke_1.wav",
     "fire":           "./wav/fire_1.wav",
     "gate":           "./wav/gate_1.wav",
     "garage":         "./wav/garage_1.wav",
     "curtain":        "./wav/curtain_1.wav",
     "light":          "./wav/light_1.wav",
     "kongtiao":       "./wav/kongtiao_1.wav"}
]

# oled显示内容
str0 = ""
str1 = ""
str2 = ""
str3 = ""

# 输入密码界面
isInput = 0                # 是否显示输入密码界面，1进入
password = "123456"        # 开门密码
psword_input = ""          # 输入的密码
inform = ""                # 提示信息
sign = 1                   # 标识符

# 烟雾火灾报警器默认关闭
# wiringpi.pinMode(smoke_pin, GPIO.OUTPUT)
# wiringpi.digitalWrite(smoke_pin, 0)
# wiringpi.pinMode(fire_pin, GPIO.OUTPUT)
# wiringpi.digitalWrite(fire_pin, 0)

# 对设备进行状态改变
def control_device(device,status):
    if(send_dict[device]!=status):
        send_dict[device] = status
        play_wav(wav_list[status][device])



# 控制舵机
def control_gate(status, pwm_pin):
    if (status == 1):
        wiringpi.softPwmWrite(pwm_pin, 15)
    else:
        wiringpi.softPwmWrite(pwm_pin, 5)

# 设置oled显示内容
@t1.job(interval=timedelta(seconds=0.1))
def set_oled_information():
        global str0
        global str1
        global str2
        global str3
        global isInput
        global password
        global psword_input
        global inform
        if(isInput):
            str0 = "#确认 A删除 B清空"
            str1 = "请输入密码"
            str2 = psword_input
            str3 = "D返回 "+inform
        else:
            now = datetime.now()
            formatted_time = now.strftime("%Y-%m-%d %H:%M")
            str0 = formatted_time
            str1 = "温度:"+send_dict["temp"]+"C"
            str2 = "湿度:"+send_dict["humidity"]+"%"
            str3 = "按*输入开门密码"
        oled.write_oled(str0, str1, str2, str3)



# 设置键盘扫描循环
@t2.job(interval=timedelta(seconds=0.02))
def set_keyboard_scan():
    global sign
    global isInput
    global psword_input
    global password
    global inform
    input = str(keyboard.key_scan())
    # print(input+"ssssssssssssssssssssssssss")
    if(input!="-1" and sign):                     # 没有按键按下时返回“-1”
        sign = 0
        if(input=="*"):                  # * 进入输入密码界面
            if(not isInput):
                psword_input = ""
                inform = ""
            isInput = 1
            return
        if (input == "C"):  # 关门
            # wiringpi.pinMode(gate_pin, GPIO.OUTPUT)
            # wiringpi.digitalWrite(gate_pin, 0)
            control_device("gate", 0)
            control_gate(0, duoji_pin)
        if(isInput):
            if(input=="#"):              # # 确认密码
                if(len(psword_input)==6 and psword_input==password):      # 密码正确，开门并返回默认界面
                    isInput = 0
                    psword_input = ""
                    inform = ""
                    # wiringpi.pinMode(gate_pin, GPIO.OUTPUT)
                    # wiringpi.digitalWrite(gate_pin, 1)
                    control_device("gate", 1)
                    control_gate(1, duoji_pin)
                elif(len(psword_input)==0):
                    inform = "请输入密码"
                elif(len(psword_input)<6):
                    inform = "密码为6位数"
                else:
                    inform = "密码错误"
                    psword_input = ""
            elif(input=="D"):            # 退出输入密码界面
                isInput = 0
                psword_input = ""
                inform = ""
            elif(input=="A"):            # 删除字符
                if(len(psword_input)>0):
                    psword_input = psword_input[:-1]
            elif(input=="B"):            # 清空密码
                psword_input = ""
            else:
                if(len(psword_input)<6):
                    psword_input = psword_input+input
    elif(input=="-1"):
        sign = 1




# 获取温度
def get_temp():
    result = subprocess.run(temp_command, shell=True, capture_output=True, text=True).stdout
    temperature_match = re.search(r"temp1:\s+([+-]?\d+\.\d+)", result)         # 正则匹配

    if temperature_match:
        temp = str(temperature_match.group(1))                               # 获取第一个符合正则的值
        return temp

# 播放音频
def play_wav(path):
    subprocess.run(wav_command+path, shell=True)


# 家庭信息获取
def get_information():

    temp = get_temp()
    send_dict["temp"] = temp

    # wiringpi.pinMode(smoke_pin, GPIO.INPUT)
    # smoke = wiringpi.digitalRead(smoke_pin)
    # send_dict["smoke"] = smoke
    #
    # wiringpi.pinMode(fire_pin, GPIO.INPUT)
    # fire = wiringpi.digitalRead(fire_pin)
    # send_dict["fire"] = fire
    #
    # wiringpi.pinMode(gate_pin, GPIO.INPUT)
    # gate = wiringpi.digitalRead(gate_pin)
    # send_dict["gate"] = gate
    #
    # wiringpi.pinMode(garage_pin, GPIO.INPUT)
    # garge = wiringpi.digitalRead(garage_pin)
    # send_dict["garage"] = garage
    #
    # wiringpi.pinMode(curtain_pin, GPIO.INPUT)
    # curtain = wiringpi.digitalRead(curtain_pin)
    # send_dict["curtain"] = curtain
    #
    # wiringpi.pinMode(light_pin, GPIO.INPUT)
    # light = wiringpi.digitalRead(light_pin)
    # send_dict["light"] = light
    #
    # wiringpi.pinMode(kongtiao_pin, GPIO.INPUT)
    # kongtiao = wiringpi.digitalRead(kongtiao_pin)
    # send_dict["kongtiao"] = kongtiao

# 家庭信息设置
def set_information(rec_json):

    global password
    global IN3
    global IN4

    rec_dict = demjson.decode(rec_json)
    print(type(rec_dict["gate"]))
    control_device("smoke",  rec_dict["smoke"])
    control_device("fire", rec_dict["fire"])
    control_device("gate", rec_dict["gate"])
    control_device("garage", rec_dict["garage"])
    control_device("curtain", rec_dict["curtain"])
    control_device("light", rec_dict["light"])
    control_device("kongtiao", rec_dict["kongtiao"])

    control_gate(rec_dict["gate"], duoji_pin)
    wiringpi.digitalWrite(IN4, rec_dict["kongtiao"])
    wiringpi.pinMode(light_pin,GPIO.OUTPUT)
    wiringpi.digitalWrite(light_pin,rec_dict["light"])


    password = rec_dict["password"]

    print(f"smoke:{rec_dict['smoke']},fire:{rec_dict['fire']},\
            gate:{rec_dict['gate']},garage:{rec_dict['garage']},\
            curtain:{rec_dict['curtain']},light:{rec_dict['light']},\
            kongtiao:{rec_dict['kongtiao']}")


    # control_device("smoke", smoke_pin, 0)
    #
    # control_device("fire", fire_pin, rec_dict["fire"])
    #
    # control_device("gate", gate_pin, rec_dict["gate"])
    # control_gate(rec_dict["gate"], duoji_pin)
    #
    # control_device("garage", garage_pin, rec_dict["garage"])
    #
    # control_device("curtain", curtain_pin, rec_dict["curtain"])
    #
    # control_device("light", light_pin, rec_dict["light"])
    #
    # control_device("kongtiao", kongtiao_pin, rec_dict["kongtiao"])
    # wiringpi.digitalWrite(IN4, rec_dict["kongtiao"])


   


# 连接函数
def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
    # flags是一个包含代理回复的标志的字典；
	# rc的值决定了连接成功或者不成功（0为成功）
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client( client_id)	# 实例化对象
    client.on_connect = on_connect	# 设定回调函数，当Broker响应连接时，就会执行给定的函数
    client.connect(broker, port)	# 连接
    return client

# 定义发送信息的函数
def publish(client) :
    while True :
        time.sleep(1)
        get_information()
        send_json = demjson.encode(str(send_dict))
        result = client.publish(publish_topic, send_json)	# 发送信息到topic
        status = result[0]	# 解析响应内容
        if status == 0:	# 发送成功
            print(f"Send to topic `{publish_topic}`")
        else:	# 发送失败
            print(f"Failed to send message to topic {publish_topic}")


def subscribe(client:mqtt_client):
    def on_message(client, userdata, msg):
        rec_json = msg.payload.decode()
        set_information(rec_json)

    client.subscribe(subscribe_topic)
    print(subscribe_topic+"ssssssssssssssssssssssssssssssssssssss")
    client.on_message = on_message


if __name__ == '__main__':
    client = connect_mqtt()		# 连接
    client.loop_start()	# 新线程loop
    subscribe(client)
    t1.start(block=False)
    t2.start(block=False)
    publish(client)	# 发送
