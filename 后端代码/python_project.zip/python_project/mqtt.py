from paho.mqtt import client as mqtt_client
import time
import random


# 服务器信息
broker = '39.106.60.146'
port = 1883
# 设备唯一ID
client_id = f'python-mqtt-{random.randint(0, 1000)}'
publish_topic = "home_01"
subscribe_topic = "home_01"

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
    # flags是一个包含代理回复的标志的字典；
	# rc的值决定了连接成功或者不成功（0为成功）
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client( client_id)	# 实例化对象
    client.on_connect = on_connect	# 设定回调函数，当Broker响应连接时，就会执行给定的函数
    client.connect(broker, port)	# 连接
    return client


# 定义发送信息的函数
def publish(client) :
    while True :
        time.sleep(1)
        result = client.publish(publish_topic, "hellowold")	# 发送信息到topic
        status = result[0]	# 解析响应内容
        if status == 0:	# 发送成功
            print(f"Send to topic `{publish_topic}`")
        else:	# 发送失败
            print(f"Failed to send message to topic {publish_topic}")

def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        rec_json = msg.payload.decode()
        print("收到")
    client.subscribe(subscribe_topic)
    client.on_message = on_message

if __name__ == '__main__':
    client = connect_mqtt()  # 连接
    client.loop_start()  # 新线程loop
    # subscribe(client)
    publish(client)  # 发送
