#!/usr/bin/python3
# -*- coding: utf-8 -*-

from mySQL_config import queryfunc,commitfunc


# 定义用户表类
class UserTB:
    ''' 用户增加、查询 '''

    def __init__(self, user, pwd):
        self.user = user
        self.pwd = pwd

    # 查询用户名
    def selectUser(self):
        sql = "select * from USERS where USERNAME = '%s'" % self.user
        result = queryfunc(sql)
        return result

    # 查询用户名密码
    def selectUserPwd(self):
        sql = "select * from USERS where USERNAME = '%s' and PASSWORD = '%s' limit 1" % (self.user, self.pwd)
        result = queryfunc(sql)
        return result

    # 插入
    def insetinto(self):
        sql = "INSERT INTO USERS (USERNAME,PASSWORD) VALUES ('%s','%s')" % (self.user, self.pwd)
        result = commitfunc(sql)
        return result

    # 删除
    def deleteUser(self):
        sql = "DELETE from USERS where USERNAME = '%s' and PASSWORD = '%s'" % (self.user, self.pwd)
        result = commitfunc(sql)
        return result
