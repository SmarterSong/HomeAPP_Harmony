import time

import paho.mqtt.client as mqtt


class mqttfunc:
    def __init__(self):
        self.postmsg = ''
        self.getmsg = ''


    def mqtt_get_data(self):
        # 当连接到MQTT服务器时的回调
        def on_connect(client, userdata, flags, rc):
            # print(f"Connected with result code {rc}")
            # 订阅一个或多个主题
            client.subscribe("home_01")

        # 当从订阅的主题接收到消息时的回调
        def on_message(client, userdata, msg):
            # print(f"Received message '{msg.payload.decode('utf-8')}' on topic '{msg.topic}' with QoS {msg.qos}")
            self.getmsg = msg.payload.decode('utf-8')

        # 创建一个MQTT客户端实例
        client = mqtt.Client(client_id="123")

        # 绑定回调函数
        client.on_connect = on_connect
        client.on_message = on_message

        # 连接到MQTT服务器
        client.connect("39.106.60.146", 1883, 60)

        # 开始MQTT客户端的网络循环
        client.loop_start()
        time.sleep(2)
        client.loop_stop()


    def mqtt_pulish_data(self):
        # MQTT服务器设置
        broker = "39.106.60.146"  # 替换为你的MQTT服务器地址
        port = 1883  # MQTT服务器端口，默认为1883
        topic = "phone_01"  # 你要发布消息的MQTT主题
        client_id = "my_python_client"  # MQTT客户端ID

        # MQTT回调函数，当收到服务器的响应时调用
        def on_connect(client, userdata, flags, rc):
            # print(f"Connected with result code {rc}")
            if rc == 0:
                print("Connected to MQTT Broker!")
            else:
                print("Failed to connect, return code %d\n", rc)
            # 连接成功后，开始发布消息
            client.subscribe(topic)  # 可选：订阅主题以接收消息
            publish_data(client)  # 开始发布数据

        # 发布数据的函数
        def publish_data(client):
            # message = f"Hello MQTT! {time.ctime()}"  # 要发送的消息内容，这里只是一个示例
            message = self.postmsg
            status = client.publish(topic, message)  # 发布消息到指定的主题
            if status[0] == 0:
                print(f"Published message: {message}")
            # time.sleep(1)  # 每5秒发送一次消息，你可以根据需要调整这个时间间

        # 创建MQTT客户端实例
        client = mqtt.Client(client_id)

        # 绑定连接回调函数
        client.on_connect = on_connect

        # 连接到MQTT服务器
        client.connect(broker, port)

        # 开始MQTT客户端的网络循环
        client.loop_start()
        # 开始发布数据
        # publish_data(client)
        time.sleep(1)
        client.loop_stop()
