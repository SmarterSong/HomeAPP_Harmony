from datetime import datetime, timedelta

import jwt


class JwtApi:
    @staticmethod
    def generate_jwt(username: str, password: str, ip_address: str) -> str:
        global encoded_jwt
        # 设置密钥和算法
        SECRET_KEY = '洛阳理工'
        ALGORITHM = 'HS256'
        # 创建 payload
        payload = {
            'user_id': username,
            'username': password,
            'ip': ip_address,
            'exp': datetime.utcnow() + timedelta(seconds=3600),  # 设置过期时间为1小时后
            'iat': datetime.utcnow()  # 当前时间
        }
        # 生成 token
        encoded_jwt = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
        # print(encoded_jwt)  # 输出生成的 token
        return encoded_jwt

    @staticmethod
    def decode_jwt(jwt_decode: str) -> int:
        # 假设你有一个JWT字符串
        jwt_token = jwt_decode
        # JWT的secret_key用于编码时签名JWT，同样也需要用于解码时验证签名
        secret_key = '洛阳理工'  # 请替换为你的密钥
        try:
            # 对JWT进行解码
            decoded_token = jwt.decode(jwt_token, secret_key, algorithms=['HS256'])
            # print(decoded_token)  # 输出解码后的payload部分，它是一个字典
            return 1
        except jwt.ExpiredSignatureError:
            # print('Token has expired')
            return 0
        except jwt.InvalidTokenError:
            # print('Invalid token')
            return -1
