import paho.mqtt.client as mqtt


# 当连接到MQTT服务器时的回调
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    # 订阅一个或多个主题
    client.subscribe("home_01")


# 当从订阅的主题接收到消息时的回调
def on_message(client, userdata, msg):
    # print(f"Received message '{msg.payload.decode('utf-8')}' on topic '{msg.topic}' with QoS {msg.qos}")
    print(msg.payload.decode('utf-8'))
    str1=str(msg.payload.decode('utf-8')).split('"')
    print(str1[1])
    return msg.payload.decode('utf-8')



'''# 创建一个MQTT客户端实例
client = mqtt.Client(client_id="123")

# 绑定回调函数
client.on_connect = on_connect
client.on_message = on_message

# 连接到MQTT服务器
client.connect("39.106.60.146", 1883, 60)

# 开始MQTT客户端的网络循环
client.loop_forever()'''

# 创建一个MQTT客户端实例
client = mqtt.Client(client_id="123")

# 绑定回调函数
client.on_connect = on_connect
client.on_message = on_message

# 连接到MQTT服务器
client.connect("39.106.60.146", 1883, 60)

# 开始MQTT客户端的网络循环
client.loop_forever()

