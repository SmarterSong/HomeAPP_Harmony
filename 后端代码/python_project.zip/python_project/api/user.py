#!/usr/bin/python3
# -*- coding: utf-8 -*-
# 导入flask模块
# 导入json模块
import json
import logging
import time

from flask import Blueprint, request

# 导入自定义模块
from Utils.utils import *
from api.jwt_api import JwtApi
from api.mqtt_api import mqttfunc
# 导入mySQL_config
from sql.user import UserTB

# 创建类的实例
user = Blueprint('user', __name__)
# 创建一个日志记录器
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
# 创建一个文件处理器，用于将日志写入文件
file_handler = logging.FileHandler('login.log')
file_handler.setLevel(logging.INFO)

# 创建一个格式化器，定义日志的格式
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)

# 将处理器添加到记录器
logger.addHandler(file_handler)


# 登录
# @param：{string}     user         用户名
# @param：{string}     pwd          密码
# @returns：{json}
@user.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        # POST、GET:
        # request.form获得所有post参数放在一个类似dict类中,to_dict()是字典化
        # 单个参数可以通过request.form.to_dict().get("xxx","")获得
        global message
        param = request.form.to_dict()
        if JwtApi.decode_jwt(request.headers.get('Authorization')) == 1:
            if request.get_json()['user'] != None and request.get_json()['pwd'] != None:
                if request.get_json()['user'] != "" and len(request.get_json()['user']) < 8 and request.get_json()[
                    'pwd'] != "" and len(
                    request.get_json()['pwd']) < 20:
                    user = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                    user = user.selectUser()
                    if user == ():
                        content = json.dumps(formatres(False, '', "用户名不存在"), ensure_ascii=False)
                    else:
                        userPwd = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                        userPwd = userPwd.selectUserPwd()
                        if userPwd == ():
                            content = json.dumps(formatres(False, '', "用户名密码不正确"), ensure_ascii=False)
                        else:
                            message = True
                            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'],
                                                        request.remote_addr)
                            content = json.dumps(formatres(True, f'{token}', "登录成功"),
                                                 ensure_ascii=False)
                            logger.info('User %s logged in successfully', request.get_json()['user'])

                else:
                    content = json.dumps(formatres(False, '', "用户名密码为空或者过长"), ensure_ascii=False)
            else:
                content = json.dumps(formatres(False, {}, "请检查参数"), ensure_ascii=False)
        elif JwtApi.decode_jwt(request.headers.get('Authorization')) == 0:
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "token已过期，请重新登录"), ensure_ascii=False)
        else:
            message = False
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "无效的token"), ensure_ascii=False)
    else:
        content = json.dumps(formatres(False, '', "101"))
    resp = Response_headers(content)
    return content


# 注册
# @param：{string}     user         用户名
# @param：{string}     pwd          密码
# @returns：{json}
@user.route('/reg', methods=['post'])
def reg():
    if request.method == 'POST':
        param = request.form.to_dict()
        if request.get_json()['user'] != None and request.get_json()['pwd'] != None:
            if request.get_json()['user'] != "" and len(request.get_json()['user']) < 8 and request.get_json()[
                'pwd'] != "" and len(
                request.get_json()['pwd']) < 20:
                user = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                user = user.selectUser()
                if user != ():
                    content = json.dumps(formatres(False, '', "用户名已存在"), ensure_ascii=False)
                else:
                    try:
                        insetintouser = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                        insetintouser = insetintouser.insetinto()
                        if insetintouser == ():
                            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'],
                                                        request.remote_addr)
                            content = json.dumps(formatres(True, f'{token}', "用户创建成功"), ensure_ascii=False)
                            logger.info('User %s Registration successfully', request.get_json()['user'])
                        else:
                            content = json.dumps(formatres(False, '', "用户创建失败"), ensure_ascii=False)
                    except:
                        content = json.dumps(formatres(False, '', "用户创建失败，可能用户名过长"), ensure_ascii=False)
            else:
                content = json.dumps(formatres(False, '', "用户名密码为空或者过长"), ensure_ascii=False)
        else:
            content = json.dumps(formatres(False, '', "请检查参数"), ensure_ascii=False)
    else:
        content = json.dumps(formatres(False, '', "101"))
    resp = Response_headers(content)
    return content


# 注销
# @param：{string}     user         用户名
# @param：{string}     pwd          密码
# @returns：{json}
@user.route('/det', methods=['post'])
def det():
    global content
    global message
    if request.method == 'POST':
        # POST、GET:
        # request.form获得所有post参数放在一个类似dict类中,to_dict()是字典化
        # 单个参数可以通过request.form.to_dict().get("xxx","")获得
        param = request.form.to_dict()
        if JwtApi.decode_jwt(request.headers.get('Authorization')) == 1:
            if request.get_json()['user'] != None and request.get_json()['pwd'] != None:
                if request.get_json()['user'] != "" and len(request.get_json()['user']) < 8 and request.get_json()[
                    'pwd'] != "" and len(
                    request.get_json()['pwd']) < 20:
                    user = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                    user = user.selectUser()
                    userPwd = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                    userPwd = userPwd.selectUserPwd()
                    if user != () and userPwd != ():
                        try:
                            deleteuser = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                            deleteuser = deleteuser.deleteUser()
                            if deleteuser == ():
                                content = json.dumps(formatres(True, '', "用户注销成功"),
                                                     ensure_ascii=False)
                            else:
                                content = json.dumps(formatres(False, '', "用户注销失败"), ensure_ascii=False)
                        except:
                            content = json.dumps(formatres(False, '', "用户注销失败"), ensure_ascii=False)
                    else:
                        content = json.dumps(formatres(False, '', "用户注销失败，可能用户已注销"),
                                             ensure_ascii=False)

            else:
                content = json.dumps(formatres(False, '', "请检查参数"), ensure_ascii=False)
        elif JwtApi.decode_jwt(request.headers.get('Authorization')) == 0:
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "token已过期，请重新登录"), ensure_ascii=False)
        else:
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "无效的token"), ensure_ascii=False)
    else:
        content = json.dumps(formatres(False, '', "101"))
    resp = Response_headers(content)
    return content


@user.route('/sse', methods=['GET'])
def send():
    def generate():
        global message
        count = 0
        getmqttdata = mqttfunc()

        while True:
            time.sleep(1)  # 每秒发送一次消息
            count += 1
            getmqttdata.mqtt_get_data()
            # data = {
            #     'id': str(count),
            #     # 'mqtt_data': f'This is message {count}',
            #     'mqtt_data': getattr(getmqttdata, 'getmsg'),
            #     'success': message
            # }
            res = {
                "success": True,
                'data': getattr(getmqttdata, 'getmsg'),
                "msg": message
            }
            yield f"data: {json.dumps(res)}\n\n"


    return Response(generate(), mimetype="text/event-stream")


@user.route('/send', methods=['POST'])
def post():
    if request.method == 'POST':
        # POST、GET:
        # request.form获得所有post参数放在一个类似dict类中,to_dict()是字典化
        # 单个参数可以通过request.form.to_dict().get("xxx","")获得
        global message
        param = request.form.to_dict()
        if JwtApi.decode_jwt(request.headers.get('Authorization')) == 1:
            if request.get_json()['user'] != None and request.get_json()['pwd'] != None:
                if request.get_json()['user'] != "" and len(request.get_json()['user']) < 11 and request.get_json()[
                    'pwd'] != "" and len(
                    request.get_json()['pwd']) < 20:
                    user = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                    user = user.selectUser()
                    if user == ():
                        content = json.dumps(formatres(False, '', "用户名不存在"), ensure_ascii=False)
                    else:
                        userPwd = UserTB(request.get_json()['user'], request.get_json()['pwd'])
                        userPwd = userPwd.selectUserPwd()
                        if userPwd == ():
                            content = json.dumps(formatres(False, '', "用户名密码不正确"), ensure_ascii=False)
                        else:
                            postmqqtdata = mqttfunc()
                            postmqqtdata.postmsg = request.get_json()['mqqtmsg']
                            postmqqtdata.mqtt_pulish_data()
                            content = json.dumps(formatres(True, '', "发送成功"),
                                                 ensure_ascii=False)
                            logger.info('User %s pulish in successfully', request.get_json()['user'])

                else:
                    content = json.dumps(formatres(False, '', "用户名密码为空或者过长"), ensure_ascii=False)
            else:
                content = json.dumps(formatres(False, '', "请检查参数"), ensure_ascii=False)
        elif JwtApi.decode_jwt(request.headers.get('Authorization')) == 0:
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "token已过期，请重新登录"), ensure_ascii=False)
        else:
            message = False
            token = JwtApi.generate_jwt(request.get_json()['user'], request.get_json()['pwd'], request.remote_addr)
            content = json.dumps(formatres(False, f'{token}', "无效的token"), ensure_ascii=False)
    else:
        content = json.dumps(formatres(False, '', "101"))
    resp = Response_headers(content)
    return content

@user.route('/post', methods=['GET'])
def sss():
    getmqttdata = mqttfunc()
    getmqttdata.mqtt_get_data()
    content = json.loads(getmqttdata.getmsg)


    return content

@user.route('/sendmsg', methods=['POST'])
def ss():
    postmqqtdata = mqttfunc()
    print(request.get_json())
    postmqqtdata.postmsg = str(request.get_json())
    postmqqtdata.mqtt_pulish_data()
    content = json.dumps(formatres(True, '', "发送成功"),
                         ensure_ascii=False)
    return content