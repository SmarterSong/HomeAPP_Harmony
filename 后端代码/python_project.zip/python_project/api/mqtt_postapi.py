import time

import paho.mqtt.client as mqtt

# MQTT服务器设置
broker = "39.106.60.146"  # 替换为你的MQTT服务器地址
port = 1883  # MQTT服务器端口，默认为1883
topic = "phone_01"  # 你要发布消息的MQTT主题
client_id = "my_python_client"  # MQTT客户端ID


# MQTT回调函数，当收到服务器的响应时调用
def on_connect(client, userdata, flags, rc):
    # print(f"Connected with result code {rc}")
    if rc == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Failed to connect, return code %d\n", rc)
    # 连接成功后，开始发布消息
    client.subscribe(topic)  # 可选：订阅主题以接收消息
    # publish_data()  # 开始发布数据


# 发布数据的函数
def publish_data(client):
    while True:
        message = f"Hello MQTT! {time.ctime()}"  # 要发送的消息内容，这里只是一个示例
        status = client.publish(topic, message)  # 发布消息到指定的主题
        if status[0] == 0:
            print(f"Published message: {message}")
        time.sleep(1)  # 每5秒发送一次消息，你可以根据需要调整这个时间间隔

'''# 创建MQTT客户端实例
client = mqtt.Client(client_id)

# 绑定连接回调函数
client.on_connect = on_connect

# 连接到MQTT服务器
client.connect(broker, port)

# 开始MQTT客户端的网络循环
client.loop_start()

# 开始发布数据
publish_data()'''


def pulishdata():
    # 创建MQTT客户端实例
    client = mqtt.Client(client_id)

    # 绑定连接回调函数
    client.on_connect = on_connect

    # 连接到MQTT服务器
    client.connect(broker, port)

    # 开始MQTT客户端的网络循环
    client.loop_start()
    time.sleep(1)
    # 开始发布数据
    publish_data(client)

pulishdata()