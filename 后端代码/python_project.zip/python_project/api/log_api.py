import logging


class write_log:
    @staticmethod
    def login_log():
        # 创建一个日志记录器
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        # 创建一个文件处理器，用于将日志写入文件
        file_handler = logging.FileHandler('login.log')
        file_handler.setLevel(logging.INFO)

        # 创建一个格式化器，定义日志的格式
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        # 将处理器添加到记录器
        logger.addHandler(file_handler)
        return logger